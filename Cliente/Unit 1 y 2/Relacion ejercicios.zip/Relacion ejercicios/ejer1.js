    //recorre todos lod números del 0 al 20
    for(let i = 0; i < 22; i++){
        if(!(i % 2)){
            document.write("Los numeros pares son: " + i + "</br>");
        }
    }