    let pregunta = ("Dame una palabra");
    let respuesta = window.prompt(pregunta);
    // Bucle que recorre la palabra desde el último carácter hasta el primero
    for(let i = respuesta.length; i >= 0; i--){
         // Obtiene el carácter en la posición 'i' y lo convierte a String para mostrarlo
        document.write(String(respuesta.charAt(i)));
    }
