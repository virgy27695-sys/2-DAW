/*Crea una clase BingoGame que represente el juego de bingo. La clase tendrá:
Propiedades:
cards:Representa el carton del bingo del jugador. Será un array bidimensional de 5*5
(5 columnas y 5 filas), donde cada fila tiene cinco números aleatorios entre 1 y 90
drawnNumbers: Array unidimensional que almacena los números que hansalido hasta el momento
lineAchieved: un booleano que insica si se ha cantado linea
Metodos;
Constructor: Al crear una nueva instancia de BingoGame, se pasa como parámetro el carton
(arraybidimensional con números entre 1 y 90 sin repetirse en cada fila)
drawNumber(): Genera un número aleatorio entre 1 y 90 que no haya salido antes, lo agrega
al array dranNumbers y lo muestra en consola */
let card = [
    [5, 18, 35, 48, 60],
    [3, 21, 40, 50, 70],
    [7, 15, 39, 54, 80],
    [10, 25, 41, 55, 78],
    [12, 28, 43, 59, 85]];

let drawnNumbers = [];
let lineAchieved = false;
let filas = card.length;;
let columnas = card[0].length;

//Creamos una nueva instancia del juego 
const bingoGame = new BingoGame(card);
function BingoGame() {
    return (
        drawnNumber() &&
        checkLine() &&
        checkBingo() && checkLine()
    );


}
//Genera numeros aleatorios del 1 - 90
function drawnNumber() {
    let max = 90;
    let aleatorios = Number((Math.random() * max + 1).toFixed(0))
    drawnNumbers.push = [aleatorios];
}


function checkBingo() {
    let resultado = [];
    for (let i = 0; i < filas; i++) {
        for (let j = 0; j < columnas; j++) {
        }
        
    }
}
function checkLine() {
    if (filas === drawnNumbers) {
        lineAchieved = true;
        console.log(drawnNumbers);
        console.log(card);
        console.log("Has cantado línea");
    }
}

// Resultado
//console.log(validarSudoku() ? "✅ Sudoku correcto" : "❌ Sudoku incorrecto");



