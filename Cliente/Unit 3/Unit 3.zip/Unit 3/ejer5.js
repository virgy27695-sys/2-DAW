//Ejercicio 5
let fechaNac = new Date(1995,6,27);
let fechaEne = new Date("2025-01-01");
if(fechaNac>fechaEne){
    console.log("He nacido este año");
}else{
    console.log("No has nacido este año");
}






